﻿Imports GMap.NET
Imports GMap.NET.WindowsForms

Public Class Form1
    Private copter_lat, copter_lon As Double
    Private WithEvents copter_marker As Markers.GMarkerGoogle
    Private WithEvents copter_layer As GMapOverlay


    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        '-7.2767636,112.7949036
        copter_lat = -7.2767636
        copter_lon = 112.7949036

        myMap.MinZoom = 5
        myMap.MaxZoom = 20
        myMap.Zoom = 17
        myMap.Position = New PointLatLng(-7.2767636, 112.7949036)
        myMap.MapProvider = MapProviders.BingSatelliteMapProvider.Instance
        myMap.Manager.Mode = AccessMode.ServerAndCache




        copter_marker = New Markers.GMarkerGoogle(New PointLatLng(-7.2767636, 112.7949036), Markers.GMarkerGoogleType.green)

        copter_layer = New GMapOverlay()
        copter_layer.Markers.Add(copter_marker)

        myMap.Overlays.Add(copter_layer)
    End Sub

    Private Sub tmr1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmr1.Tick
        Randomize()
        Dim delta_lat As Double = ((100 * Rnd()) + 20) / 10000000.0
        Dim delta_lon As Double = ((100 * Rnd()) + 20) / 10000000.0
        Dim not_lat As Single = Rnd()
        Dim not_lon As Single = Rnd()

        If not_lat >= 0.5 Then
            copter_lat += delta_lat
        Else
            copter_lat -= delta_lat
        End If
        If not_lon >= 0.5 Then
            copter_lon += delta_lon
        Else
            copter_lon -= delta_lon
        End If

        update_map()
    End Sub

    Private Sub btnMove_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnMove.Click
        If tmr1.Enabled Then
            tmr1.Enabled = False
            MsgBox("Random Move stop")
        Else
            tmr1.Enabled = True
            MsgBox("Random Move start")
        End If
    End Sub

    Private Sub myMap_OnMapZoomChanged() Handles myMap.OnMapZoomChanged
        lblInfo.Text = "Info : Lat= " + CStr(copter_lat) + ", Lon= " + CStr(copter_lon) + ", Zoom Level= " + CStr(myMap.Zoom)
    End Sub

    Private Sub update_map()
        copter_marker.Position = New PointLatLng(copter_lat, copter_lon)
        myMap.UpdateMarkerLocalPosition(copter_marker)
        lblInfo.Text = "Info : Lat= " + CStr(copter_lat) + ", Lon= " + CStr(copter_lon) + ", Zoom Level= " + CStr(myMap.Zoom)
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
End Class